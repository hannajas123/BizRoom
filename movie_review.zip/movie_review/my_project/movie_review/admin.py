from django.contrib import admin

from movie_review.models import *

# Register your models here.
admin.site.register(Movies)
admin.site.register(Login)